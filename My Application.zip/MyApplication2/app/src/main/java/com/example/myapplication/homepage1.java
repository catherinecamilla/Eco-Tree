package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class homepage1 extends AppCompatActivity {

    Button btnnext, btnnext2;
    EditText etemail, etpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage1);

        etemail = findViewById(R.id.editText2);
        etpassword = findViewById(R.id.editText3);

        btnnext = findViewById(R.id.textButton2);

        //btnnext2 = findViewById(R.id.Button);

        //btnnext2.setOnClickListener(new View.OnClickListener() {


        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email, password, logEmail, logPassword;

                email = getIntent().getStringExtra("Email");
                password = getIntent().getStringExtra("Password");

                logEmail = etemail.getText().toString().trim();
                logPassword = etpassword.getText().toString().trim();

                if ((logEmail.equals(email) && logPassword.equals(password))) {
                    Intent intent = new Intent(getApplicationContext(),Volunteer.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Account not found!", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void SignUp(View view) {

        Intent intent = new Intent(getApplicationContext(), SignUp.class);
        startActivity(intent);
    }
}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignUp extends AppCompatActivity {

    Button btnnext3;
    EditText etLName, etFName, etContact, etAddress, etEmail, etPassword;
    TextView testDisplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etLName=findViewById(R.id.editTextTextPersonName3);
        etFName=findViewById(R.id.editTextTextPersonName5);
        etContact=findViewById(R.id.editTextNumber);
        etAddress=findViewById(R.id.editTextTextPersonName7);
        etEmail=findViewById(R.id.editTextTextEmailAddress);
        etPassword=findViewById(R.id.editTextTextPassword);

        btnnext3=findViewById(R.id.button3);

        //testDisplay =findViewById(R.id.textView13);
//
        btnnext3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String strLName, strFName, strContact,strAddress, strEmail, strPassword;

                strLName= etLName.getText().toString().trim();
                strFName= etFName.getText().toString().trim();
                strAddress= etAddress.getText().toString().trim();
                strContact=etContact.getText().toString().trim();
                strEmail=etEmail.getText().toString().trim();
                strPassword=etPassword.getText().toString().trim();

            //testDisplay.setText(strLName+","+strFName+","+strAddress+","+strContact+","+strEmail+","+strPassword);


                Intent intent = new Intent(getApplicationContext(),homepage1.class);
                intent.putExtra("Lname",strLName);
                intent.putExtra("Fname",strFName);
                intent.putExtra("Address",strAddress);
                intent.putExtra("Contact",strContact);
                intent.putExtra("Email",strEmail);
                intent.putExtra("Password",strPassword);
                startActivity(intent);
            }
        });
    }
}
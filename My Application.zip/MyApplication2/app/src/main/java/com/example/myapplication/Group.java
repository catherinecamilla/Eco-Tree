package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Group extends AppCompatActivity {

    Button btndenr, btnharibon,btnnuvali;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);

        btnnuvali = findViewById(R.id.button5);
        btndenr = findViewById(R.id.button2);
        btnharibon = findViewById(R.id.button);

        btnnuvali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Nuvali.class);
                startActivity(intent);
            }
        });

       btndenr.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(getApplicationContext(),Denr.class);
               startActivity(intent);
           }
       });

        btnharibon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Haribon.class);
                startActivity(intent);
            }
        });


    }
}